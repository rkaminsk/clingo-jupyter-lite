x = 1

__getattr__ = "Surprise!"
__dir__ = "Surprise again!"
